import os, json, pymysql, jwt
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

# 1) 환경변수에서 DB 접속 정보 읽기
REQUIRED_VARS = ["DB_HOST", "DB_USER", "DB_PASSWORD", "DB_NAME"]
missing = [k for k in REQUIRED_VARS if not os.getenv(k)]
if missing:
    raise RuntimeError(f"Missing required environment variables: {', '.join(missing)}")

DB_HOST = os.getenv("DB_HOST")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_NAME = os.getenv("DB_NAME")
DB_PORT = int(os.getenv("DB_PORT", "3306"))

JWT_SECRET  = os.getenv("JWT_SECRET", "change-me")
JWT_EXP_MIN = int(os.getenv("JWT_EXP_MIN", "60"))

def issue_jwt(org_id: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": org_id,  # 사업자번호
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=JWT_EXP_MIN)).timestamp()),
        "iss": "slim-site"
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def require_auth(event) -> str:
    auth = (event.get("headers") or {}).get("Authorization") or ""
    if not auth.startswith("Bearer "):
        raise PermissionError("missing bearer token")
    token = auth.split(" ", 1)[1].strip()
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"], options={"require":["exp","iat","sub"]})
        return payload["sub"]  # org_id
    except jwt.ExpiredSignatureError:
        raise PermissionError("token expired")
    except jwt.InvalidTokenError:
        raise PermissionError("invalid token")

# ★ 누락된 함수 추가 ★
def get_conn():
    return pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        db=DB_NAME,
        port=DB_PORT,
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
        connect_timeout=5,
        read_timeout=10,
        write_timeout=10,
    )

def _json_default(o):
    if isinstance(o, (datetime, date)):
        return o.isoformat(sep=" ", timespec="seconds")
    if isinstance(o, Decimal):
        return float(o)
    raise TypeError(f"Object of type {type(o).__name__} is not JSON serializable")

def _resp(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json; charset=utf-8",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
        },
        "body": json.dumps(body, ensure_ascii=False, default=_json_default),
    }

# 로그인 함수
def login(event):
    try:
        body = json.loads(event.get("body") or "{}")
        business_number = body.get("businessNumber")
        password = body.get("password")
        
        if not business_number or not password:
            return _resp(400, {"ok": False, "message": "사업자번호와 비밀번호를 입력해주세요."})
        
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업자 인증 확인
                cur.execute("""
                    SELECT org_id, org_name, password_hash 
                    FROM organizations 
                    WHERE business_number = %s AND is_active = 1
                """, (business_number,))
                
                org = cur.fetchone()
                if not org:
                    return _resp(401, {"ok": False, "message": "등록되지 않은 사업자번호입니다."})
                
                # 비밀번호 확인 (실제로는 해시 비교해야 함)
                if org["password_hash"] != password:  # 임시로 평문 비교
                    return _resp(401, {"ok": False, "message": "비밀번호가 일치하지 않습니다."})
                
                # JWT 토큰 발급
                token = issue_jwt(org["org_id"])
                
                return _resp(200, {
                    "ok": True,
                    "token": token,
                    "user": {
                        "orgId": org["org_id"],
                        "orgName": org["org_name"],
                        "businessNumber": business_number
                    }
                })
                
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"로그인 처리 중 오류가 발생했습니다: {str(e)}"})

# 토큰 검증 함수
def verify_token(event):
    try:
        org_id = require_auth(event)
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT org_id, org_name, business_number 
                    FROM organizations 
                    WHERE org_id = %s AND is_active = 1
                """, (org_id,))
                
                org = cur.fetchone()
                if not org:
                    return _resp(401, {"ok": False, "message": "유효하지 않은 토큰입니다."})
                
                return _resp(200, {
                    "ok": True,
                    "user": {
                        "orgId": org["org_id"],
                        "orgName": org["org_name"],
                        "businessNumber": org["business_number"]
                    }
                })
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"토큰 검증 중 오류가 발생했습니다: {str(e)}"})

# 사업 목록 조회
def get_businesses(event):
    try:
        org_id = require_auth(event)
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT business_id, business_name, business_type, 
                           target_count, created_at, updated_at
                    FROM businesses 
                    WHERE org_id = %s AND is_active = 1
                    ORDER BY created_at DESC
                """, (org_id,))
                
                businesses = cur.fetchall()
                return _resp(200, {"ok": True, "data": businesses})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"사업 목록 조회 중 오류가 발생했습니다: {str(e)}"})

# 사업 상세 조회
def get_business(event, business_id):
    try:
        org_id = require_auth(event)
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT business_id, business_name, business_type, 
                           target_count, created_at, updated_at
                    FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                business = cur.fetchone()
                if not business:
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                return _resp(200, {"ok": True, "data": business})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"사업 조회 중 오류가 발생했습니다: {str(e)}"})

# 사업 생성
def create_business(event):
    try:
        org_id = require_auth(event)
        body = json.loads(event.get("body") or "{}")
        
        business_name = body.get("businessName")
        business_type = body.get("businessType")
        
        if not business_name:
            return _resp(400, {"ok": False, "message": "사업명을 입력해주세요."})
        
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO businesses (org_id, business_name, business_type, target_count, is_active)
                    VALUES (%s, %s, %s, 0, 1)
                """, (org_id, business_name, business_type))
                
                business_id = cur.lastrowid
                
                return _resp(201, {
                    "ok": True, 
                    "message": "사업이 생성되었습니다.",
                    "data": {"businessId": business_id}
                })
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"사업 생성 중 오류가 발생했습니다: {str(e)}"})

# 사업 수정
def update_business(event, business_id):
    try:
        org_id = require_auth(event)
        body = json.loads(event.get("body") or "{}")
        
        business_name = body.get("businessName")
        business_type = body.get("businessType")
        
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업 존재 확인
                cur.execute("""
                    SELECT business_id FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                # 사업 정보 업데이트
                update_fields = []
                params = []
                
                if business_name:
                    update_fields.append("business_name = %s")
                    params.append(business_name)
                
                if business_type:
                    update_fields.append("business_type = %s")
                    params.append(business_type)
                
                if update_fields:
                    update_fields.append("updated_at = NOW()")
                    params.extend([business_id, org_id])
                    
                    cur.execute(f"""
                        UPDATE businesses 
                        SET {', '.join(update_fields)}
                        WHERE business_id = %s AND org_id = %s
                    """, params)
                
                return _resp(200, {"ok": True, "message": "사업 정보가 수정되었습니다."})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"사업 수정 중 오류가 발생했습니다: {str(e)}"})

# 사업 삭제
def delete_business(event, business_id):
    try:
        org_id = require_auth(event)
        
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업 존재 확인
                cur.execute("""
                    SELECT business_id FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                # 사업 삭제 (soft delete)
                cur.execute("""
                    UPDATE businesses 
                    SET is_active = 0, updated_at = NOW()
                    WHERE business_id = %s AND org_id = %s
                """, (business_id, org_id))
                
                return _resp(200, {"ok": True, "message": "사업이 삭제되었습니다."})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"사업 삭제 중 오류가 발생했습니다: {str(e)}"})

# 대상자 목록 조회
def get_targets(event, business_id):
    try:
        org_id = require_auth(event)
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업 권한 확인
                cur.execute("""
                    SELECT business_id FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                # 대상자 목록 조회
                cur.execute("""
                    SELECT target_id, name, phone, email, address, 
                           target_type, created_at, updated_at
                    FROM targets 
                    WHERE business_id = %s AND is_active = 1
                    ORDER BY created_at DESC
                """, (business_id,))
                
                targets = cur.fetchall()
                return _resp(200, {"ok": True, "data": targets})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"대상자 목록 조회 중 오류가 발생했습니다: {str(e)}"})

# 대상자 상세 조회
def get_target(event, business_id, target_id):
    try:
        org_id = require_auth(event)
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업 권한 확인
                cur.execute("""
                    SELECT business_id FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                # 대상자 조회
                cur.execute("""
                    SELECT target_id, name, phone, email, address, 
                           target_type, created_at, updated_at
                    FROM targets 
                    WHERE target_id = %s AND business_id = %s AND is_active = 1
                """, (target_id, business_id))
                
                target = cur.fetchone()
                if not target:
                    return _resp(404, {"ok": False, "message": "대상자를 찾을 수 없습니다."})
                
                return _resp(200, {"ok": True, "data": target})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"대상자 조회 중 오류가 발생했습니다: {str(e)}"})

# 대상자 생성
def create_target(event, business_id):
    try:
        org_id = require_auth(event)
        body = json.loads(event.get("body") or "{}")
        
        name = body.get("name")
        phone = body.get("phone")
        email = body.get("email")
        address = body.get("address")
        target_type = body.get("targetType")
        
        if not name:
            return _resp(400, {"ok": False, "message": "이름을 입력해주세요."})
        
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업 권한 확인
                cur.execute("""
                    SELECT business_id FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                # 대상자 생성
                cur.execute("""
                    INSERT INTO targets (business_id, name, phone, email, address, target_type, is_active)
                    VALUES (%s, %s, %s, %s, %s, %s, 1)
                """, (business_id, name, phone, email, address, target_type))
                
                target_id = cur.lastrowid
                
                # 사업의 대상자 수 증가
                cur.execute("""
                    UPDATE businesses 
                    SET target_count = target_count + 1, updated_at = NOW()
                    WHERE business_id = %s
                """, (business_id,))
                
                return _resp(201, {
                    "ok": True, 
                    "message": "대상자가 생성되었습니다.",
                    "data": {"targetId": target_id}
                })
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"대상자 생성 중 오류가 발생했습니다: {str(e)}"})

# 대상자 수정
def update_target(event, business_id, target_id):
    try:
        org_id = require_auth(event)
        body = json.loads(event.get("body") or "{}")
        
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업 권한 확인
                cur.execute("""
                    SELECT business_id FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                # 대상자 존재 확인
                cur.execute("""
                    SELECT target_id FROM targets 
                    WHERE target_id = %s AND business_id = %s AND is_active = 1
                """, (target_id, business_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "대상자를 찾을 수 없습니다."})
                
                # 대상자 정보 업데이트
                update_fields = []
                params = []
                
                for field, value in body.items():
                    if value is not None:
                        if field == "targetType":
                            update_fields.append("target_type = %s")
                        else:
                            update_fields.append(f"{field} = %s")
                        params.append(value)
                
                if update_fields:
                    update_fields.append("updated_at = NOW()")
                    params.extend([target_id, business_id])
                    
                    cur.execute(f"""
                        UPDATE targets 
                        SET {', '.join(update_fields)}
                        WHERE target_id = %s AND business_id = %s
                    """, params)
                
                return _resp(200, {"ok": True, "message": "대상자 정보가 수정되었습니다."})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"대상자 수정 중 오류가 발생했습니다: {str(e)}"})

# 대상자 삭제
def delete_target(event, business_id, target_id):
    try:
        org_id = require_auth(event)
        
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업 권한 확인
                cur.execute("""
                    SELECT business_id FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                # 대상자 존재 확인
                cur.execute("""
                    SELECT target_id FROM targets 
                    WHERE target_id = %s AND business_id = %s AND is_active = 1
                """, (target_id, business_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "대상자를 찾을 수 없습니다."})
                
                # 대상자 삭제 (soft delete)
                cur.execute("""
                    UPDATE targets 
                    SET is_active = 0, updated_at = NOW()
                    WHERE target_id = %s AND business_id = %s
                """, (target_id, business_id))
                
                # 사업의 대상자 수 감소
                cur.execute("""
                    UPDATE businesses 
                    SET target_count = target_count - 1, updated_at = NOW()
                    WHERE business_id = %s
                """, (business_id,))
                
                return _resp(200, {"ok": True, "message": "대상자가 삭제되었습니다."})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"대상자 삭제 중 오류가 발생했습니다: {str(e)}"})

# 대상자 검색
def search_targets(event, business_id):
    try:
        org_id = require_auth(event)
        query_params = event.get("queryStringParameters") or {}
        search_term = query_params.get("q", "")
        
        if not search_term:
            return _resp(400, {"ok": False, "message": "검색어를 입력해주세요."})
        
        with get_conn() as conn:
            with conn.cursor() as cur:
                # 사업 권한 확인
                cur.execute("""
                    SELECT business_id FROM businesses 
                    WHERE business_id = %s AND org_id = %s AND is_active = 1
                """, (business_id, org_id))
                
                if not cur.fetchone():
                    return _resp(404, {"ok": False, "message": "사업을 찾을 수 없습니다."})
                
                # 대상자 검색
                search_pattern = f"%{search_term}%"
                cur.execute("""
                    SELECT target_id, name, phone, email, address, 
                           target_type, created_at, updated_at
                    FROM targets 
                    WHERE business_id = %s AND is_active = 1
                    AND (name LIKE %s OR phone LIKE %s OR email LIKE %s)
                    ORDER BY created_at DESC
                """, (business_id, search_pattern, search_pattern, search_pattern))
                
                targets = cur.fetchall()
                return _resp(200, {"ok": True, "data": targets})
                
    except PermissionError as e:
        return _resp(401, {"ok": False, "message": str(e)})
    except Exception as e:
        return _resp(500, {"ok": False, "message": f"대상자 검색 중 오류가 발생했습니다: {str(e)}"})

def handler(event, context):
    path = (event.get("rawPath") or event.get("path") or "").rstrip("/") or "/"
    method = (event.get("requestContext", {}).get("http", {}).get("method")
              or event.get("httpMethod") or "GET").upper()
    
    # OPTIONS 요청 처리 (CORS preflight)
    if method == "OPTIONS":
        return _resp(200, {"ok": True})
    
    try:
        # Health check
        if path == "/health":
            return _resp(200, {"ok": True, "message": "healthy"})
        
        # 인증 관련 엔드포인트
        if path == "/login" and method == "POST":
            return login(event)
        
        if path == "/auth/verify" and method == "GET":
            return verify_token(event)
        
        if path == "/auth/logout" and method == "POST":
            return _resp(200, {"ok": True, "message": "로그아웃되었습니다."})
        
        # 사업 관련 엔드포인트
        if path == "/businesses" and method == "GET":
            return get_businesses(event)
        
        if path == "/businesses" and method == "POST":
            return create_business(event)
        
        # 사업 상세/수정/삭제 (동적 경로)
        if path.startswith("/businesses/"):
            path_parts = path.split("/")
            if len(path_parts) >= 3:
                business_id = path_parts[2]
                
                if len(path_parts) == 3:  # /businesses/{id}
                    if method == "GET":
                        return get_business(event, business_id)
                    elif method == "PUT":
                        return update_business(event, business_id)
                    elif method == "DELETE":
                        return delete_business(event, business_id)
                
                elif len(path_parts) == 4 and path_parts[3] == "targets":  # /businesses/{id}/targets
                    if method == "GET":
                        return get_targets(event, business_id)
                    elif method == "POST":
                        return create_target(event, business_id)
                
                elif len(path_parts) == 5 and path_parts[3] == "targets":  # /businesses/{id}/targets/{target_id}
                    target_id = path_parts[4]
                    if method == "GET":
                        return get_target(event, business_id, target_id)
                    elif method == "PUT":
                        return update_target(event, business_id, target_id)
                    elif method == "DELETE":
                        return delete_target(event, business_id, target_id)
                
                elif len(path_parts) == 5 and path_parts[3] == "targets" and path_parts[4] == "search":  # /businesses/{id}/targets/search
                    if method == "GET":
                        return search_targets(event, business_id)
        
        # 기본 응답 (DB 연결 테스트)
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT NOW() AS server_time")
                rows = cur.fetchall()
        return _resp(200, {"ok": True, "data": rows})

    except Exception as e:
        return _resp(500, {"ok": False, "error": str(e)})

def lambda_handler(event, context):
    return handler(event, context)
